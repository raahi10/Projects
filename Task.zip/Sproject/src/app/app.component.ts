import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'project';
  lat = 51.678418;
  lng = 7.809007;
  constructor (private httpService: HttpClient) { }
  statesData: string [];
  currStateData: string = '';
  getName(stateName: any): void {
    if ( stateName!== 'SELECT') { // SELECT is used for default here
      this.httpService.get('./assets/states-and-districts.json').subscribe(
        data => {
          this.currStateData = data.states.find(x => x.state == stateName).districts;
          //console.log('ll',this.currStateData.districts)
        },
        (err: HttpErrorResponse) => {
          console.log (err.message);
        }
      );
      
    }
  }
  onChoose($event)
  {console.log($event,'rahul')
    this.lat=event.coords.lat;
    this.lng=event.coords.lng;
  }
  ngOnInit () {
    this.httpService.get('./assets/states-and-districts.json').subscribe(
      data => {
        console.log(data.states,'rr')
        
        this.statesData = data.states as string [];	 // FILL THE ARRAY WITH DATA.
        //  console.log(this.arrBirds[1]);
      },
      (err: HttpErrorResponse) => {
        console.log (err.message);
      }
    );
  }
}
